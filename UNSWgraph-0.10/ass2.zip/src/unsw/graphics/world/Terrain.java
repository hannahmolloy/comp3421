package unsw.graphics.world;

import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.jogamp.opengl.GL;
import com.jogamp.opengl.GL3;

import unsw.graphics.CoordFrame3D;
import unsw.graphics.Matrix4;
import unsw.graphics.Shader;
import unsw.graphics.Texture;
import unsw.graphics.Vector3;
import unsw.graphics.geometry.Point2D;
import unsw.graphics.geometry.Point3D;
import unsw.graphics.geometry.TriangleMesh;

/**
 * COMMENT: Comment HeightMap 
 *
 * @author malcolmr
 */
public class Terrain {

    private int width;
    private int depth;
    private float[][] altitudes;
    private List<Tree> trees;
    private List<Road> roads;
    private Vector3 sunlight;
    private Texture terrainTex;
    private TriangleMesh mesh;

    /**
     * Create a new terrain
     *
     * @param width The number of vertices in the x-direction
     * @param depth The number of vertices in the z-direction
     */
    public Terrain(int width, int depth, Vector3 sunlight) {
        this.width = width;
        this.depth = depth;
        altitudes = new float[width][depth];
        trees = new ArrayList<Tree>();
        roads = new ArrayList<Road>();
        this.sunlight = sunlight;
    }
    
    public void init(GL3 gl) {
    	mesh = createMesh(gl);
    	mesh.init(gl);
    }

	public List<Tree> trees() {
        return trees;
    }

    public List<Road> roads() {
        return roads;
    }

    public Vector3 getSunlight() {
        return sunlight;
    }

    /**
     * Set the sunlight direction. 
     * 
     * Note: the sun should be treated as a directional light, without a position
     * 
     * @param dx
     * @param dy
     * @param dz
     */
    public void setSunlightDir(float dx, float dy, float dz) {
        sunlight = new Vector3(dx, dy, dz);      
    }

    /**
     * Get the altitude at a grid point
     * 
     * @param x
     * @param z
     * @return
     */
    public double getGridAltitude(int x, int z) {
        return altitudes[x][z];
    }

    /**
     * Set the altitude at a grid point
     * 
     * @param x
     * @param z
     * @return
     */
    public void setGridAltitude(int x, int z, float h) {
        altitudes[x][z] = h;
    }

    /**
     * Get the altitude at an arbitrary point. 
     * Non-integer points should be interpolated from neighbouring grid points
     * 
     * @param x
     * @param z
     * @return
     */
    public float altitude(float x, float z) {
    	// ignore if out of the bounds 
        float altitude = 0;

    	if((x > this.width - 1 || x < 0) || (z < 0) || z > this.depth - 1){
    		return altitude;
    	}
    	// enclose the point in a square made of the floors and ceilings
        int xmin = (int) Math.floor(x);
        int xmax = (int) Math.ceil(x);
        int zmax = (int) Math.floor(z);
        int zmin = (int) Math.ceil(z);
        
        // on an integer/vertex, so return
        if(xmin == xmax && zmin == zmax) {
        	return (float) getGridAltitude(xmin, zmin);
        }
        
        // else linear interpolation to calculate the altitude 
        if(xmin == x || xmax == x) {
        	altitude = lerp(z, zmin, zmax, (float) getGridAltitude((int) x, zmin), (float) getGridAltitude((int) x, zmax));
        } else if(zmin == z || zmax == z) {
        	altitude = lerp(x, xmin, xmax, (float) getGridAltitude(xmin, (int) z), (float) getGridAltitude(xmax, (int) z));
        } else if(distance(x, xmin, z, zmax) < distance(x, xmax, z, zmin)) {	// top triangle
        	altitude = blerp(x, z, xmax, zmax, xmin, zmin);
        } else {																// bottom triangle
        	altitude = blerp(x, z, xmin, zmin, xmax, zmax);
        }
		
        return altitude;
    }
    // calculate distance between two points
    private float distance (float x1, float x2, float z1, float z2) {
    	
    	return (float) Math.sqrt(Math.pow((x1 - x2), 2) + Math.pow((z1 - z2), 2));
    }

    // generic linear interpolation
    private float lerp(float a, float a1, float a2, float b1, float b2) {
    	
        return b1 + (b2 - b1) * ((a - a1)/(a2 - a1));
    }

    // bilinear interpolation
    private float blerp(float x, float z, float Bx, float Bz, float Cx, float Cz) {
    	
    	float Ax = Cx;
    	float Az = Bz;
    	float Dx = Cx;
    	float Dz = z;
    	float Ex = lerp(z, Bz, Cz, Bx, Cx);
    	float Ez = z;
    	
    	float Dy = lerp(z, Az, Cz, (float) getGridAltitude((int)Ax, (int)Az), (float)getGridAltitude((int)Cx, (int)Cz));
    	float Ey = lerp(z, Bz, Cz, (float) getGridAltitude((int)Bx, (int)Bz), (float)getGridAltitude((int)Cx, (int)Cz));
    	
    	return lerp(x, Dx, Ex, Dy, Ey); 
    }


    public int getWidth() {
		return this.width;
	}

    public int getHeight() {
		return this.depth;
	}
    
	/**
     * Add a tree at the specified (x,z) point. 
     * The tree's y coordinate is calculated from the altitude of the terrain at that point.
     * 
     * @param x
     * @param z
     */
    public void addTree(float x, float z) {
        float y = altitude(x, z);
        Tree tree = new Tree(x, y, z);
        trees.add(tree);
    }

    /**
     * Add a road. 
     * 
     * @param x
     * @param z
     */
    public void addRoad(float width, List<Point2D> spine) {
    	float altitude = altitude(spine.get(0).getX(), spine.get(0).getY());
        Road road = new Road(width, spine, altitude);
        roads.add(road);        
    }

    /*
     * function that creates the triangle mesh
     */
    private TriangleMesh createMesh(GL3 gl) {
    	
    	List<Point3D> points = new ArrayList<Point3D>();
    	List<Integer> indices = new ArrayList<Integer>();
    	List<Point2D> texCoords = new ArrayList<Point2D>();
    	float row;
    	float col;
    	
    	for (row = 0; row < depth; row++) {
    		for (col = 0; col < width; col++) {
    			/* for each square of points 
    			 * two triangles need to be made
    			 * 	topLeft  	topRight
						   +-----+
						   |    /|
						   |  /  |
						   |/    |
						   +-----+
					bottomLeft	 bottomRight
    			 */

    			points.add(new Point3D(row, (float)altitude(row, col), col));
    			texCoords.add(new Point2D(row, col));
    			
    			if (row < depth - 1 && col < width - 1) {
    				int topLeft = (int) (row * width + col);
        			int topRight = (int) (row * width + col + 1);
        			int bottomLeft = (int) ((row + 1) * width + col);
        			int bottomRight = (int) ((row + 1) * width + col + 1);
        			
        			indices.add(new Integer(topLeft));
        			indices.add(new Integer(topRight));
        			indices.add(new Integer(bottomLeft));
        			
        			indices.add(new Integer(bottomLeft));
        			indices.add(new Integer(topRight));
        			indices.add(new Integer(bottomRight));
    			}
    		}
    	}

		return new TriangleMesh(points, indices, true, texCoords);
	}
    
    public void draw(GL3 gl) throws IOException {
    	terrainTex = new Texture(gl, "res/textures/grass.bmp","bmp", true);
    	
    	Shader.setInt(gl, "tex", 0);
    	gl.glActiveTexture(GL.GL_TEXTURE0);
    	gl.glBindTexture(GL.GL_TEXTURE_2D, terrainTex.getId());
    	
    	Shader.setPenColor(gl, Color.green);
    	mesh.draw(gl);
    	
    	Shader.setPenColor(gl, Color.WHITE);
    	for (Tree t : trees) {
    		CoordFrame3D frame = CoordFrame3D.identity()
    					.translate(t.getPosition())
    					.translate(0, 1f, 0)
    					.scale(0.2f, 0.2f, 0.2f);
    		t.draw(gl, frame);
    	}
    	
    	for (Road r : roads) {
    		CoordFrame3D frame = CoordFrame3D.identity();
    		r.draw(gl, frame);
    	}
    }
}
